#include <string>
#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <netdb.h>
#include <vector>
#include <algorithm>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <fcntl.h>
#include <errno.h>

#include "../include/global.h"
#include "../include/logger.h"

struct ClientInfo {
    std::string hostname;
    std::string ip;
    int port;
    bool logged_in;
    int fd;          
};

static int serversock = -1;
static std::vector<ClientInfo> table;

static inline bool send_line(int fd, const std::string& s){
    std::string x = s; x.push_back('\n');
    ssize_t n = send(fd, x.c_str(), (ssize_t)x.size(), 0);
    return n == (ssize_t)x.size();
}
static bool recv_line(int fd, std::string& out){
    out.clear();
    char ch;
    while (true){
        ssize_t n = recv(fd, &ch, 1, 0);
        if (n <= 0) return false;
        if (ch == '\n') break;
        out.push_back(ch);
        if ((int)out.size() > 4096) break;
    }
    return true;
}

static std::string hostname_from_ip(const std::string& ip){
    sockaddr_in sa{}; sa.sin_family = AF_INET;
    if (inet_pton(AF_INET, ip.c_str(), &sa.sin_addr) != 1) return "";
    char host[NI_MAXHOST];
    if (getnameinfo((sockaddr*)&sa, sizeof(sa), host, sizeof(host),
                    nullptr, 0, NI_NAMEREQD) == 0)
        return std::string(host);
    return ip;
}
static bool validLoginArgs(const std::string& ip, const std::string& port){
    if (ip.empty() || port.empty()) return false;

    sockaddr_in tmp{};
    if (inet_pton(AF_INET, ip.c_str(), &tmp.sin_addr) != 1) return false;

    if (!std::all_of(port.begin(), port.end(), ::isdigit)) return false;

    long v = strtol(port.c_str(), nullptr, 10);
    return (v > 0 && v <= 65535);
}

static std::string getIp(){
    std::string ip;
    int s=socket(AF_INET,SOCK_DGRAM,0);
    if(s>=0){
        sockaddr_in dst{},me{};
        dst.sin_family=AF_INET; dst.sin_port=htons(53);
        inet_pton(AF_INET,"8.8.8.8",&dst.sin_addr);
        if(connect(s,(sockaddr*)&dst,sizeof(dst))==0){
            socklen_t len=sizeof(me);
            if(getsockname(s,(sockaddr*)&me,&len)==0){
                char buf[INET_ADDRSTRLEN];
                if(inet_ntop(AF_INET,&me.sin_addr,buf,sizeof(buf))) ip=buf;
            }
        }
        close(s);
    }
    return ip;
}
static void print_LIST(const char* tag, const std::vector<ClientInfo>& table){
    std::vector<ClientInfo> rows;
    for(const auto& c:table) if(c.logged_in) rows.push_back(c);
    std::sort(rows.begin(),rows.end(),[](const ClientInfo&a,const ClientInfo&b){
        if(a.port!=b.port) return a.port<b.port;
        if(a.hostname!=b.hostname) return a.hostname<b.hostname;
        return a.ip<b.ip;
    });
    cse4589_print_and_log("[%s:SUCCESS]\n", tag);
    int i=1;
    for(const auto& c:rows)
        cse4589_print_and_log("%-5d%-35s%-20s%-8d\n",
                              i++, c.hostname.c_str(), c.ip.c_str(), c.port);
    cse4589_print_and_log("[%s:END]\n", tag);
}
static bool update_client_list_from_server(int fd){
    char buf[4096];
    ssize_t n=recv(fd,buf,sizeof(buf)-1,0);
    if(n<=0) return false;
    buf[n]='\0';
    table.clear();
    std::istringstream iss(buf);
    std::string host, ip; int port;
    while(iss>>host>>ip>>port)
        table.push_back(ClientInfo{host,ip,port,true,-1});
    return true;
}
static bool send_client_list(int fd, const std::vector<ClientInfo>& table){
    std::ostringstream oss;
    for(const auto& c:table) if(c.logged_in)
        oss<<c.hostname<<" "<<c.ip<<" "<<c.port<<"\n";
    std::string data=oss.str();
    if(data.empty()) data="\n";
    return send(fd,data.c_str(),(ssize_t)data.size(),0)==(ssize_t)data.size();
}
static bool commonCMD(const std::string& cmd, char** argv){
    if(cmd=="AUTHOR"){
        cse4589_print_and_log("[AUTHOR:SUCCESS]\n");
        cse4589_print_and_log("I, %s, have read and understood the course academic integrity policy.\n","pklair-beibitzh");
        cse4589_print_and_log("[AUTHOR:END]\n");
        return true;
    }
    if(cmd=="IP"){
        std::string ip=getIp();
        if(ip.empty()||ip=="127.0.0.1"){ cse4589_print_and_log("[IP:ERROR]\n"); cse4589_print_and_log("[IP:END]\n"); }
        else { cse4589_print_and_log("[IP:SUCCESS]\n"); cse4589_print_and_log("IP:%s\n", ip.c_str()); cse4589_print_and_log("[IP:END]\n"); }
        return true;
    }
    if(cmd=="PORT"){
        cse4589_print_and_log("[PORT:SUCCESS]\n");
        cse4589_print_and_log("PORT:%s\n", argv[2]);
        cse4589_print_and_log("[PORT:END]\n");
        return true;
    }
    if(cmd=="EXIT"){
        cse4589_print_and_log("[EXIT:SUCCESS]\n");
        cse4589_print_and_log("[EXIT:END]\n");
        return true;
    }
    return false;
}

int main(int argc, char **argv){
    cse4589_init_log(argv[2]);
    fclose(fopen(LOGFILE,"w"));
    bool isClient=(argv[1][0]=='c');

    if(isClient){
        bool logged_in=false;
        std::string line;
        while(std::getline(std::cin,line)){
            if(line.empty()) continue;
            std::istringstream ss(line);
            std::string cmd; ss>>cmd;

            if(!logged_in && cmd!="AUTHOR"&&cmd!="IP"&&cmd!="PORT"&&cmd!="LOGIN"&&cmd!="EXIT"){
                cse4589_print_and_log("[%s:ERROR]\n", cmd.c_str());
                cse4589_print_and_log("[%s:END]\n",   cmd.c_str());
                continue;
            }

            if(commonCMD(cmd,argv)){
                if(cmd=="EXIT"){ if(serversock>=0){ close(serversock); serversock=-1; } break; }
                continue;
            }

            if(cmd=="LOGIN"){
                std::string ipArg, portArg, extra;
                if(!(ss>>ipArg>>portArg) || (ss>>extra) || !validLoginArgs(ipArg,portArg)){
                    cse4589_print_and_log("[LOGIN:ERROR]\n"); cse4589_print_and_log("[LOGIN:END]\n"); continue; close(serversock); serversock=-1;
                }
                int sockfd=socket(AF_INET,SOCK_STREAM,0);
                sockaddr_in srv{}; srv.sin_family=AF_INET; srv.sin_port=htons(atoi(portArg.c_str()));
                inet_pton(AF_INET,ipArg.c_str(),&srv.sin_addr);
                if(sockfd<0 || connect(sockfd,(sockaddr*)&srv,sizeof(srv))!=0){
                    if(sockfd>=0) close(sockfd);
                    cse4589_print_and_log("[LOGIN:ERROR]\n"); cse4589_print_and_log("[LOGIN:END]\n"); continue;
                }
                serversock=sockfd;

                int my_listen_port = atoi(argv[2]);
                if(my_listen_port<=0 || !send_line(serversock, std::to_string(my_listen_port))){
                    cse4589_print_and_log("[LOGIN:ERROR]\n"); cse4589_print_and_log("[LOGIN:END]\n");
                    close(serversock); serversock=-1; continue;
                }

                if(update_client_list_from_server(serversock)){
                    cse4589_print_and_log("[LOGIN:SUCCESS]\n"); cse4589_print_and_log("[LOGIN:END]\n"); logged_in=true;
                }else{
                    cse4589_print_and_log("[LOGIN:ERROR]\n"); cse4589_print_and_log("[LOGIN:END]\n");
                    close(serversock); serversock=-1;
                }
            }
            else if(cmd=="REFRESH"){
                if(!logged_in || serversock<0){
                    cse4589_print_and_log("[REFRESH:ERROR]\n"); cse4589_print_and_log("[REFRESH:END]\n");
                }else{
                    if(send_line(serversock,"R") && update_client_list_from_server(serversock)){
                        cse4589_print_and_log("[REFRESH:SUCCESS]\n"); cse4589_print_and_log("[REFRESH:END]\n");
                    }else{
                        cse4589_print_and_log("[REFRESH:ERROR]\n"); cse4589_print_and_log("[REFRESH:END]\n");
                    }
                }
            }
            else if(cmd=="LIST"){
                if(!logged_in){ cse4589_print_and_log("[LIST:ERROR]\n"); cse4589_print_and_log("[LIST:END]\n"); }
                else{ print_LIST("LIST", table); }
            }
            else{
                cse4589_print_and_log("[%s:ERROR]\n", cmd.c_str());
                cse4589_print_and_log("[%s:END]\n",   cmd.c_str());
            }
        }
    } else {
        int listen_port=atoi(argv[2]);
        int server_fd=socket(AF_INET,SOCK_STREAM,0);
        int yes=1; setsockopt(server_fd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));
        sockaddr_in addr{}; addr.sin_family=AF_INET; addr.sin_addr.s_addr=INADDR_ANY; addr.sin_port=htons(listen_port);
        bind(server_fd,(sockaddr*)&addr,sizeof(addr));
        listen(server_fd,10);

        fd_set master,readfds;
        FD_ZERO(&master); FD_SET(server_fd,&master); FD_SET(STDIN_FILENO,&master);
        int fdmax=std::max(server_fd,STDIN_FILENO);
        bool running=true;

        while(running){
            readfds=master;
            if(select(fdmax+1,&readfds,nullptr,nullptr,nullptr)<0) continue;

            if(FD_ISSET(STDIN_FILENO,&readfds)){
                std::string line; if(!std::getline(std::cin,line)) break;
                if(line.empty()) continue;
                std::istringstream ss(line); std::string cmd; ss>>cmd;
                if(cmd=="LOGIN"){ cse4589_print_and_log("[LOGIN:ERROR]\n"); cse4589_print_and_log("[LOGIN:END]\n"); continue; }
                if(commonCMD(cmd,argv)){ if(cmd=="EXIT") running=false; continue; }
                if(cmd=="LIST"){ print_LIST("LIST", table); continue; }
                cse4589_print_and_log("[%s:ERROR]\n", cmd.c_str()); cse4589_print_and_log("[%s:END]\n", cmd.c_str());
            }

            if(FD_ISSET(server_fd,&readfds)){
                sockaddr_in cli{}; socklen_t len=sizeof(cli);
                int cfd=accept(server_fd,(sockaddr*)&cli,&len);
                if(cfd<0) continue;

                std::string first;
                if(!recv_line(cfd, first)){ close(cfd); continue; }
                int listen_p = 0; try { listen_p = std::stoi(first); } catch(...) { listen_p = 0; }
                if(listen_p<=0 || listen_p>65535){ close(cfd); continue; }

                char ip[INET_ADDRSTRLEN]; inet_ntop(AF_INET,&cli.sin_addr,ip,sizeof(ip));
                std::string host=hostname_from_ip(ip);

                table.push_back(ClientInfo{host, ip, listen_p, true, cfd});

                send_client_list(cfd,table);

                FD_SET(cfd,&master); if(cfd>fdmax) fdmax=cfd;
            }

            for(int fd=0; fd<=fdmax; ++fd){
                if(fd==server_fd || fd==STDIN_FILENO) continue;
                if(!FD_ISSET(fd,&readfds)) continue;

                std::string req;
                if(!recv_line(fd, req)){
                    for(auto it=table.begin(); it!=table.end(); ++it){
                        if(it->fd==fd){ table.erase(it); break; }
                    }
                    close(fd); FD_CLR(fd,&master);
                    continue;
                }
                if(req=="R"){
                    send_client_list(fd, table);
                }
            }
        }
        for(int fd=0; fd<=fdmax; ++fd) if(FD_ISSET(fd,&master)) close(fd);
    }

    return 0;
}